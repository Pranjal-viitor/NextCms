module.exports = {
  images: {
    domains: ['nextblog.focalat.com', 'secure.gravatar.com'],
  },
}
